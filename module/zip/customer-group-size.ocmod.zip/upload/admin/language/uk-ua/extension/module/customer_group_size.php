<?php

/*
@name     Customer Group Size
@author   Andrii Burkatskyi, ocmod.space@gmail.com
@version  1.0.1
@link     https://www.ocmod.space/customer-group-size
@link     https://github.com/ocmod-space/ocmod-customer-group-size
@licence  https://raw.githubusercontent.com/ocmod-space/ocmod-customer-group-size/main/LICENSE.txt
*/

$_['heading_title'] = '#ocmod.space: customer-group-size';
$_['text_extension'] = 'Розширення';
$_['text_edit'] = 'Редагування параметрів <b>Customer Group Size</b>';
$_['text_success'] = 'Готово! Параметри модуля <b>Customer Group Size</b> збережено.';
$_['error_permission'] = 'Увага! Недостатньо прав для редагування параметрів модуля<b>Customer Group Size</b>!';
$_['text_made'] = 'Зроблено з <i class="fa fa-heart-o" aria-hidden="true"></i> в Україні';

$_['text_about'] = 'Розширення <b>Customer Group Size</b> показує кількість клієнтів у групах.';

$_['entry_status'] = 'Статус';
$_['column_size'] = 'Клієнтів';


