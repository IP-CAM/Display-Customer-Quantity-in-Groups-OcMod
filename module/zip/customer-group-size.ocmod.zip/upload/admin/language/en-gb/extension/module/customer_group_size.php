<?php

/*
@name     Customer Group Size
@author   Andrii Burkatskyi, ocmod.space@gmail.com
@version  1.0.1
@link     https://www.ocmod.space/customer-group-size
@link     https://github.com/ocmod-space/ocmod-customer-group-size
@licence  https://raw.githubusercontent.com/ocmod-space/ocmod-customer-group-size/main/LICENSE.txt
*/

$_['heading_title'] = '#ocmod.space: customer-group-size';
$_['text_extension'] = 'Extensions';
$_['text_edit'] = 'Edit <b>Customer Group Size</b>';
$_['text_success'] = 'Success! The <b>Customer Group Size</b> module settings have been saved.';
$_['error_permission'] = 'Warning! You do not have permission to modify the module <b>Customer Group Size</b>. ';
$_['text_made'] = 'Made with <i class="fa fa-heart-o" aria-hidden="true"></i> in Ukraine';

$_['text_about'] = 'The extension displays the number of customers in customer groups.';

$_['entry_status'] = 'Status';
$_['column_size'] = 'Customers';
