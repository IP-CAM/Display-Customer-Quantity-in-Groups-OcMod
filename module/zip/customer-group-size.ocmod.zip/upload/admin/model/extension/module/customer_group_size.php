<?php

/*
@name     Customer Group Size
@author   Andrii Burkatskyi, ocmod.space@gmail.com
@version  1.0.2
@link     https://www.ocmod.space/customer-group-size
@link     https://github.com/ocmod-space/ocmod-customer-group-size
@licence  https://raw.githubusercontent.com/ocmod-space/ocmod-customer-group-size/main/LICENSE.txt
*/

class ModelExtensionModuleCustomerGroupSize extends Model {
	public function getCustomerGroupSize($customer_group_id) {
		$sql = '';

		$sql .= 'SELECT COUNT(*) as `size` ';
		$sql .= 'FROM `' . DB_PREFIX . 'customer` ';
		$sql .= 'WHERE ';
		$sql .= '`customer_group_id` = "' . (int)$customer_group_id . '"';

		return $this->db->query($sql)->row['size'];
	}
}
